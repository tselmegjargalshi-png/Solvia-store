/**
 * Minimal local type declarations for the parts of React 19 this app uses.
 *
 * Why this exists: React 19 does not ship its own types, and @types/react could
 * not be installed in the build environment (no package-registry access). These
 * declarations let `npm run typecheck` check the app's own code (hooks, context,
 * component props, API types). DOM element props are intentionally loose.
 *
 * When you can install packages: `npm i -D @types/react @types/react-dom`,
 * then delete this file — the official types take over with no code changes.
 */
declare module 'react' {
  export type ReactNode = ReactElement | string | number | bigint | boolean | null | undefined | Iterable<ReactNode>;
  export interface ReactElement<P = any> {
    type: any;
    props: P;
    key: string | null;
  }
  export type Key = string | number;
  export type SetStateAction<S> = S | ((prev: S) => S);
  export type Dispatch<A> = (value: A) => void;
  export type FC<P = {}> = (props: P) => ReactNode;
  export type ComponentType<P = {}> = ((props: P) => ReactNode) | (new (props: P) => Component<P, any>);
  export type PropsWithChildren<P = {}> = P & { children?: ReactNode };
  export interface RefObject<T> {
    current: T;
  }
  export interface Context<T> {
    Provider: (props: { value: T; children?: ReactNode }) => ReactNode;
    Consumer: (props: { children: (value: T) => ReactNode }) => ReactNode;
  }

  export function useState<S>(initial: S | (() => S)): [S, Dispatch<SetStateAction<S>>];
  export function useState<S = undefined>(): [S | undefined, Dispatch<SetStateAction<S | undefined>>];
  export function useEffect(effect: () => void | (() => void), deps?: readonly unknown[]): void;
  export function useLayoutEffect(effect: () => void | (() => void), deps?: readonly unknown[]): void;
  export function useRef<T>(initial: T): RefObject<T>;
  export function useRef<T>(initial: T | null): RefObject<T | null>;
  export function useRef<T = undefined>(): RefObject<T | undefined>;
  export function useMemo<T>(factory: () => T, deps: readonly unknown[]): T;
  export function useCallback<T extends (...args: any[]) => any>(fn: T, deps: readonly unknown[]): T;
  export function useContext<T>(ctx: Context<T>): T;
  export function createContext<T>(defaultValue: T): Context<T>;
  export function useId(): string;
  export function lazy<T extends ComponentType<any>>(factory: () => Promise<{ default: T }>): T;
  export const Suspense: (props: { fallback?: ReactNode; children?: ReactNode }) => ReactNode;
  export const StrictMode: (props: { children?: ReactNode }) => ReactNode;
  export const Fragment: (props: { children?: ReactNode }) => ReactNode;

  export class Component<P = {}, S = {}> {
    constructor(props: P);
    props: Readonly<P> & { children?: ReactNode };
    state: Readonly<S>;
    setState(state: Partial<S> | ((prev: S, props: P) => Partial<S>), cb?: () => void): void;
    forceUpdate(): void;
    render(): ReactNode;
  }

  // ---- Events (structural subset of the DOM-backed synthetic events) ----
  export interface SyntheticEvent<T = Element, E = Event> {
    currentTarget: T;
    target: EventTarget & T;
    nativeEvent: E;
    defaultPrevented: boolean;
    preventDefault(): void;
    stopPropagation(): void;
    type: string;
  }
  export interface FormEvent<T = Element> extends SyntheticEvent<T> {}
  export interface ChangeEvent<T = Element> extends SyntheticEvent<T> {
    target: EventTarget & T;
  }
  export interface MouseEvent<T = Element> extends SyntheticEvent<T, globalThis.MouseEvent> {
    button: number;
    metaKey: boolean;
    ctrlKey: boolean;
    shiftKey: boolean;
    altKey: boolean;
    clientX: number;
    clientY: number;
  }
  export interface KeyboardEvent<T = Element> extends SyntheticEvent<T, globalThis.KeyboardEvent> {
    key: string;
    code: string;
    metaKey: boolean;
    ctrlKey: boolean;
    shiftKey: boolean;
    altKey: boolean;
  }

  // ---- Element attribute bags (loose by design) ----
  interface LooseAttrs {
    [key: string]: any;
    children?: ReactNode;
    className?: string;
    id?: string;
  }
  export interface HTMLAttributes<T = Element> extends LooseAttrs {}
  export interface AnchorHTMLAttributes<T = HTMLAnchorElement> extends LooseAttrs {
    href?: string;
    target?: string;
    rel?: string;
    onClick?: (e: MouseEvent<T>) => void;
  }
  export interface InputHTMLAttributes<T = HTMLInputElement> extends LooseAttrs {}
  export interface SelectHTMLAttributes<T = HTMLSelectElement> extends LooseAttrs {}
  export interface TextareaHTMLAttributes<T = HTMLTextAreaElement> extends LooseAttrs {}
  export interface ButtonHTMLAttributes<T = HTMLButtonElement> extends LooseAttrs {}
}

declare module 'react/jsx-runtime' {
  import type { ReactElement, ReactNode } from 'react';
  export namespace JSX {
    type Element = ReactElement;
    type ElementType = string | ((props: any) => ReactNode) | (new (props: any) => ElementClass);
    interface ElementClass {
      render(): ReactNode;
    }
    interface ElementAttributesProperty {
      props: {};
    }
    interface ElementChildrenAttribute {
      children: {};
    }
    interface IntrinsicAttributes {
      key?: string | number | null;
    }
    interface IntrinsicElements {
      [tag: string]: any;
    }
  }
  export const jsx: any;
  export const jsxs: any;
  export const Fragment: any;
}

declare module 'react-dom/client' {
  import type { ReactNode } from 'react';
  export function createRoot(el: Element | DocumentFragment): { render(node: ReactNode): void; unmount(): void };
}

declare module '*.css' {}
